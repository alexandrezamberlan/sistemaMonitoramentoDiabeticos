class LLM:
    pass