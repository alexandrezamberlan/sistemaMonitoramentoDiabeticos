class GeradorJSON:
    pass