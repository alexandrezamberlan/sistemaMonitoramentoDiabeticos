from django.apps import AppConfig


class RegistroRefeicaoConfig(AppConfig):
    name = 'registro_refeicao'
