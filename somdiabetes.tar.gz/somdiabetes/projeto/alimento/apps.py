from django.apps import AppConfig


class AlimentoConfig(AppConfig):
    name = 'alimento'
