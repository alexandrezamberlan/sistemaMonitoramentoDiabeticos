from django.apps import AppConfig


class MedicamentoConfig(AppConfig):
    name = 'medicamento'
