from django.apps import AppConfig


class AvisoConfig(AppConfig):
    name = 'aviso'
