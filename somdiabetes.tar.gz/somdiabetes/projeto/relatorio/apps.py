from django.apps import AppConfig


class RelatorioConfig(AppConfig):
    name = 'relatorio'
