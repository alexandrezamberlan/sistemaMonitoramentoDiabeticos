from django.conf.urls import include
from django.urls import path
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('core.urls')),
    
    path('cliente/', include('appcliente.urls')), 
    
    path('alimento/', include('alimento.urls')), 
    path('aviso/', include('aviso.urls')), 
    path('dado_clinico/', include('dado_clinico.urls')),
    path('exercicio/', include('exercicio.urls')), 
    path('medicamento/', include('medicamento.urls')), 
    path('registro_atividade/', include('registro_atividade.urls')), 
    path('registro_refeicao/', include('registro_refeicao.urls')), 
    path('relatorio/', include('relatorio.urls')), 
    path('usuario/', include('usuario.urls')), 
    path('accounts/', include('django.contrib.auth.urls')),
]

#url para arquivos de media quando em desenvolvimento
if settings.DEBUG:
    urlpatterns += staticfiles_urlpatterns()
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

urlpatterns += static(settings.STATIC_URL, 
    document_root = settings.STATIC_ROOT)   
