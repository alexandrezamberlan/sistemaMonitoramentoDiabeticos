from django.apps import AppConfig


class AppclienteConfig(AppConfig):
    name = 'appcliente'
