from django.apps import AppConfig


class DadoClinicoConfig(AppConfig):
    name = 'dado_clinico'
