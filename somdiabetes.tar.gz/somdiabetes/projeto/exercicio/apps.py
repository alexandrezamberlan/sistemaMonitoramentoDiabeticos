from django.apps import AppConfig


class ExercicioConfig(AppConfig):
    name = 'exercicio'
