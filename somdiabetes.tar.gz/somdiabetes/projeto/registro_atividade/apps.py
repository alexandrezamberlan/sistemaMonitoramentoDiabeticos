from django.apps import AppConfig


class RegistroAtividadeConfig(AppConfig):
    name = 'registro_atividade'
